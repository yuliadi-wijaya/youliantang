<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | Baris bahasa berikut digunakan oleh perpustakaan paginator untuk membuat
    | tautan-tautan paginasi sederhana. Anda bebas mengubahnya sesuai dengan
    | keinginan Anda untuk menyesuaikan tampilan aplikasi Anda.
    |
    */

    'previous' => '&laquo; Sebelumnya',
    'next' => 'Berikutnya &raquo;',

];
