<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Baris-baris Bahasa untuk Otentikasi
    |--------------------------------------------------------------------------
    |
    | Baris-baris bahasa berikut digunakan selama otentikasi untuk berbagai
    | pesan yang perlu kami tampilkan kepada pengguna. Anda bebas memodifikasi
    | baris-baris bahasa ini sesuai dengan kebutuhan aplikasi Anda.
    |
    */

    'failed' => 'Kredensial ini tidak cocok dengan catatan kami.',
    'throttle' => 'Terlalu banyak percobaan login. Silakan coba lagi dalam :seconds detik.',

];
