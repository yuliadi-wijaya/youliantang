<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <?php echo e(date('Y')); ?> © <?php echo e(AppSetting('footer_left')); ?>

            </div>
            <div class="col-sm-6">
                <div class="text-sm-right d-none d-sm-block">
                    <?php echo e(AppSetting('footer_right')); ?>

                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH E:\Data\Project\youliantang\resources\views/layouts/footer.blade.php ENDPATH**/ ?>