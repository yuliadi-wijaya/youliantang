<?php echo $__env->yieldContent('css'); ?>
 <!-- App css -->
<link href="<?php echo e(URL::asset('assets/css/bootstrap-dark.min.css')); ?>" id="bootstrap-dark" disabled rel="stylesheet" type="text/css" />
<link href="<?php echo e(URL::asset('assets/css/bootstrap.min.css')); ?>" id="bootstrap-light" rel="stylesheet" type="text/css" />
<link href="<?php echo e(URL::asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(URL::asset('assets/css/app-rtl.min.css')); ?>" id="app-rtl" disabled rel="stylesheet"  type="text/css" />
<link href="<?php echo e(URL::asset('assets/css/app-dark.min.css')); ?>" id="app-dark" disabled rel="stylesheet" type="text/css" />
<link href="<?php echo e(URL::asset('assets/css/app.min.css')); ?>" id="app-light" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets/libs/toastr/toastr.min.css')); ?>">

<?php echo $__env->yieldContent('css-bottom'); ?>
<?php /**PATH /Users/yuliadiwijaya/Documents/Freelance/You Lian tAng/youliantang/resources/views/layouts/head.blade.php ENDPATH**/ ?>