<?php $__env->startSection('title'); ?> <?php echo e(__('Invoice Details')); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

<body data-topbar="dark" data-layout="horizontal">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .print-invoice {
        display: none;
        width: 75mm;
    }

    @media print {
        .view-invoice {
            display: none;
        }

        @page {
            size: 58mm 120mm;
            margin: 0;
        }
        body {
            font-family: 'Courier New', monospace;
            margin: 0;
        }
        .print-invoice {
            display: block;
            margin: 0;
            page-break-after: auto;
        }

        .print-invoice td {
            font-size: 8pt;
            padding: 3px 2px 3px 2px;
            white-space: pre-line;
            word-wrap: break-word;
            vertical-align: top;
        }
    }
</style>
<!-- start page title -->
<?php $__env->startComponent('components.breadcrumb'); ?>
<?php $__env->slot('title'); ?> Invoice Details <?php $__env->endSlot(); ?>
<?php $__env->slot('li_1'); ?> Dashboard <?php $__env->endSlot(); ?>
<?php $__env->slot('li_2'); ?> Invoice List <?php $__env->endSlot(); ?>
<?php $__env->slot('li_3'); ?> Invoice Details <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<!-- end page title -->
<div class="row d-print-none">
    <div class="col-12">
        <a href="<?php echo e(url('invoice')); ?>">
            <button type="button" class="btn btn-primary waves-effect waves-light mb-4">
                <i class="bx bx-arrow-back font-size-16 align-middle mr-2"></i><?php echo e(__('Back to Invoice List')); ?>

            </button>
        </a>
        <a href="javascript:window.print()" class="btn btn-dark waves-effect waves-light mb-4">
            <i class="fa fa-print"></i>
        </a>
        
    </div>
</div>
<div class="view-invoice">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header" style="background-color: #2a3042 !important">
                    <div class="invoice-title">
                        <div class="col-12 text-center text-white">
                            <img src="<?php echo e(URL::asset('assets/images/logo-light.png')); ?>" alt="" width="300" style="margin:-37px 0 -60px 0">
                        </div>
                        <div class="col-12 text-center text-white mb-2" style="font-size: 10pt">
                            Ruko Inkopal Blok C6-C7, Kelapa Gading Barat, Jakarta Utara
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="row">
                                <div class="col-12 mb-1"><strong><?php echo e(__('Receptionist : ')); ?></strong><?php echo e($receptionist->first_name . " " . $receptionist->last_name); ?></div>
                                <div class="col-12 mb-1"><strong><?php echo e(__('Bill To : ')); ?></strong></div>
                                <div class="col-12 mb-1"><?php echo e($invoices->customer_name); ?></div>
                                <div class="col-12"><?php echo e($invoices->customer_phone_number); ?></div>
                            </div>
                        </div>
                        <div class="col-6 pull-right" style="text-align: right">
                            <div class="row">
                                <div class="col-12"><h5>#<?php echo e($invoices->invoice_code); ?></h5></div>
                                <div class="col-12 mb-1"><strong><?php echo e(__('Invoice Date : ')); ?></strong><?php echo e(date("d-m-Y", strtotime($invoices->treatment_date))); ?></div>
                            </div>
                        </div>
                    </div>

                    <div class="py-2 mt-3">
                        <h3 class="font-size-15 font-weight-bold"><?php echo e(__('Invoice Summary')); ?></h3>
                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th style="width: 70px;"><?php echo e(__('No.')); ?></th>
                                    <th><?php echo e(__('Product Name')); ?></th>
                                    <th class="text-right"><?php echo e(__('Amount')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $invoice_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($row->product_name); ?></td>
                                        <td class="text-right">Rp <?php echo e(number_format($row->amount)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="2" class="text-right"><?php echo e(__('Sub Total')); ?></td>
                                    <td class="text-right">Rp <?php echo e(number_format($invoices->total_price)); ?></td>
                                </tr>
                                <?php if($invoices->discount > 0): ?>
                                    <tr>
                                        <td colspan="2" class="text-right">
                                            <?php echo e(__('Discount')); ?> 
                                            <?php if($invoices->use_member != 1 && $invoices->voucher_code != ''): ?>
                                            (<strong><?php echo e($invoices->voucher_code); ?></strong>)
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-right">Rp <?php echo e(number_format($invoices->discount)); ?></td>
                                    </tr>
                                <?php endif; ?>
                                <?php if($invoices->tax_amount > 0): ?>
                                    <tr>
                                        <td colspan="2" class="text-right"><?php echo e(__('PPN ('.$invoices->tax_rate.'%)')); ?></td>
                                        <td class="text-right">Rp <?php echo e(number_format($invoices->tax_amount)); ?></td>
                                    </tr>
                                <?php endif; ?>
                                <tr style="border-top: 1px solid #2a3042;">
                                    <td colspan="2" class="border-0 text-right">
                                        <h3><?php echo e(__('Total')); ?></h3>
                                    </td>
                                    <td class="border-0 text-right">
                                        <h3 class="m-0">Rp <?php echo e(number_format($invoices->grand_total)); ?></h3>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="print-invoice">
    <div class="invoice-title mb-3">
        <div class="col-12 text-center text-white">
            <img src="<?php echo e(URL::asset('assets/images/logo-dark.png')); ?>" alt="" width="225" style="margin:-30px 0 -48px 0">
        </div>
        <div class="col-12 text-center mb-2" style="font-size: 8pt">
            Ruko Inkopal Blok C6-C7
            Kelapa Gading Barat, Jakarta Utara
        </div>
    </div>
    <div class="row mb-3" style="font-size: 8pt">
        <div class="col-12 text-center font-weight-bold mb-1"><h6><strong>Receipt #<?php echo e($invoices->invoice_code); ?></strong></h6></div>
        <div class="col-6">
            <div class="row">
                <div class="col-12 mb-1 font-weight-bold"><?php echo e(date("d-m-Y", strtotime($invoices->treatment_date))); ?></div>
                <div class="col-12 font-weight-bold"><?php echo e(__('Bill To: ')); ?></div>
                <div class="col-12"><?php echo e($invoices->customer_name); ?></div>
                <div class="col-12"><?php echo e($invoices->customer_phone_number); ?></div>
            </div>
        </div>
        <div class="col-6 pull-right" style="text-align: right">
            <div class="row">
                <div class="col-12 mb-1 font-weight-bold"><?php echo e(date("H:m", strtotime($invoices->created_at))); ?></div>
                <div class="col-12 font-weight-bold"><?php echo e(__('Cashier: ')); ?></div>
                <div class="col-12"><?php echo e($receptionist->first_name . " " . $receptionist->last_name); ?></div>
            </div>
        </div>
    </div>
    <table cellpadding="0" cellspacing="0" style="width: 100%">
        <tr style="border-top:1px dashed grey; border-bottom:1px dashed grey">
            <td class="font-weight-bold">Product Name</td>
            <td class="font-weight-bold" style="width: 90px; text-align:right">Amount</td>
        </tr>

        <?php $__currentLoopData = $invoice_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row->product_name); ?></td>
                <td class="text-right">Rp <?php echo e(number_format($row->amount)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr style="border-top:1px dashed grey;">
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
    </table>
    <div class="row" style="font-size: 8pt; margin-top: -10px">
        <div class="col-6 mb-1"><?php echo e(__('Sub Total')); ?></div>
        <div class="col-6 mb-1 text-right">Rp <?php echo e(number_format($invoices->total_price)); ?></div>

        <?php if($invoices->discount > 0): ?>
            <div class="col-6 mb-1"><?php echo e(__('Discount')); ?></div>
            <div class="col-6 mb-1 text-right">Rp <?php echo e(number_format($invoices->discount)); ?></div>
        <?php endif; ?>

        <?php if($invoices->tax_amount > 0): ?>
            <div class="col-6 mb-1"><?php echo e(__('PPN ('.$invoices->tax_rate.'%)')); ?></div>
            <div class="col-6 mb-1 text-right">Rp <?php echo e(number_format($invoices->tax_amount)); ?></div>
        <?php endif; ?>
        <div class="col-6 mb-1"><h6><strong><?php echo e(__('Total')); ?></strong></h6></div>
        <div class="col-6 mb-1 text-right"><h6><strong>Rp <?php echo e(number_format($invoices->grand_total)); ?></strong></h6></div>
    </div>
    <div class="row mt-3" style="font-size: 8pt">
        <div class="col-12 text-center font-weight-bold">Thank you for your visit</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yuliadiwijaya/Documents/Freelance/You Lian tAng/youliantang/resources/views/invoice/view-invoice-new.blade.php ENDPATH**/ ?>