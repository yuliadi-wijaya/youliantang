INSERT INTO `role_access` (`user_id`, `access_code`, `created_at`, `updated_at`) VALUES
(1, 'ALL', NULL, NULL),
(4, 'CK', NULL, NULL),
(5, 'NC', NULL, NULL);
