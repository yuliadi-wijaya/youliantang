ALTER TABLE users MODIFY COLUMN phone_number varchar(20) NULL;
