<?php

return [
    // General
    'status' => [
        0 => 'In Active',
        1 => 'Active',
    ],

    // Membership
    'membership' => [
        'benefit_discount_type' => [
                0 => 'Fix Rate',
                1 => 'Percentage',
            ],
        ],
    ];