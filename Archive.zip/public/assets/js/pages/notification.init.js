$(document).ready(function(){

    setTimeout(function(){

        $(".auto").slideUp(1000);

    }, 6000);

});
